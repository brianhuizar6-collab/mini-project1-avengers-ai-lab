# Databricks notebook source
# MAGIC %md
# MAGIC ## 04 — Stage 2: Catalog & Publish
# MAGIC
# MAGIC Databricks equivalent of `glue_jobs/catalog_and_publish_job.py`. On AWS this
# MAGIC stage ran `MSCK REPAIR TABLE` so Athena would see the new partitions Stage 1
# MAGIC just wrote. Delta tables track their own partitions automatically, so there's
# MAGIC no repair step needed — instead this stage does the two things a real "make it
# MAGIC ready to serve" step would do on Databricks:
# MAGIC
# MAGIC 1. Republish the small dimension tables (`curated_customers`, `curated_products`)
# MAGIC    in full, same as the original design.
# MAGIC 2. `OPTIMIZE` + refresh statistics on `curated_transactions` so the queries in
# MAGIC    `05_queries.sql` run fast against compacted files.
# MAGIC
# MAGIC This keeps the pipeline at two orchestrated stages (requirement 7) with a real
# MAGIC dependency: this notebook assumes Stage 1 has already run at least once.

# COMMAND ----------

dbutils.widgets.text("catalog", "sales_pipeline")
dbutils.widgets.text("schema", "dev")

CATALOG = dbutils.widgets.get("catalog")
SCHEMA = dbutils.widgets.get("schema")
RAW_BASE = f"/Volumes/{CATALOG}/{SCHEMA}/raw_data/raw"

# COMMAND ----------

customers = spark.read.option("header", True).option("inferSchema", True).csv(f"{RAW_BASE}/customers")
products = spark.read.option("header", True).option("inferSchema", True).csv(f"{RAW_BASE}/products")

customers.write.format("delta").mode("overwrite").option("overwriteSchema", "true") \
    .saveAsTable(f"{CATALOG}.{SCHEMA}.curated_customers")
products.write.format("delta").mode("overwrite").option("overwriteSchema", "true") \
    .saveAsTable(f"{CATALOG}.{SCHEMA}.curated_products")

# COMMAND ----------

spark.sql(f"OPTIMIZE {CATALOG}.{SCHEMA}.curated_transactions")
spark.sql(f"ANALYZE TABLE {CATALOG}.{SCHEMA}.curated_transactions COMPUTE STATISTICS")

# COMMAND ----------

result = spark.sql(f"SELECT COUNT(*) AS curated_count FROM {CATALOG}.{SCHEMA}.curated_transactions").collect()
print(f"curated.transactions is queryable — {result[0]['curated_count']} rows")
