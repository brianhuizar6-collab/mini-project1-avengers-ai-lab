# Customer Sales Analytics Pipeline — Databricks Free Edition build

Same pipeline as the AWS Console version (`sales-pipeline-project`), rebuilt on
Databricks Free Edition. Everything runs through the Databricks UI — no CLI,
no external cloud account needed beyond signing up for Free Edition.

Mapping from the AWS build:

| AWS piece | Databricks Free Edition piece |
|---|---|
| S3 raw/rejected/curated zones | Unity Catalog Volume (raw) + Delta tables (rejected, curated) |
| Glue Crawler + schema docs | `spark.read.option("inferSchema", True)` + the same `docs/schema-*.md` writeup |
| Glue Stage 1 job (`clean-and-curate`) | `03_clean_and_curate_job` notebook |
| Glue Stage 2 job (`catalog-and-publish`) | `04_catalog_and_publish_job` notebook |
| Athena queries | Databricks SQL editor / SQL warehouse, `05_queries.sql` |
| Step Functions | Databricks Workflows (Jobs), 2 tasks with a dependency |
| CloudWatch counts | printed notebook output + `run_metrics` Delta table |
| `etl/transform.py` | logic unchanged, **inlined directly into** `03_clean_and_curate_job` and `06_rerun_proof` (see note below) |

**Note on transform.py:** an earlier version of this bundle shipped `transform.py`
as its own workspace file, imported with `from transform import clean_and_curate`.
Some Free Edition workspaces hit an `OSError: [Errno 5] Input/output error` trying
to read a plain (non-notebook) `.py` file that way — a workspace-file quirk, not
a bug in the code. The fix: the transform functions are now pasted directly into
the two notebooks that need them, so there's no cross-file import at all. If
you still have an old standalone `transform.py` in your workspace folder, you
can delete it — nothing references it anymore.

## 0. Sign up

Go to Databricks and create a **Free Edition** account (separate from the old
"Community Edition" — Free Edition is the current one and is closer to the
full product). This gives you a workspace with serverless-only compute, one
small SQL warehouse, and Unity Catalog.

## 1. Import these files into your workspace

Workspace (left sidebar) → your user folder → **Create → Folder**, name it
`sales-pipeline`. Then, for each file in this bundle: **Import** (the ⬆ icon,
or right-click the folder → Import) → upload the `.py` / `.sql` file. Databricks
auto-detects the `# Databricks notebook source` header and imports each `.py`
as a proper notebook.

Put all files in the **same folder** for consistency, though it no longer
matters for imports specifically — `transform.py` isn't part of this bundle
anymore (see note above).

## 2. Run 00_setup

Open `00_setup`, check `SHOW CATALOGS` output first. If your Free Edition
account can create catalogs, run it as-is. If `CREATE CATALOG` errors with a
permission message, edit the `CATALOG` variable to the catalog name Free
Edition already gave you, comment out the `CREATE CATALOG` line, and re-run —
the schema and Volume creation still work inside an existing catalog.

This produces:
- schema `<catalog>.dev`
- Volume `<catalog>.dev.raw_data`, mounted at `/Volumes/<catalog>/dev/raw_data`

## 3. Run 01_generate_synthetic_data

Attach to serverless compute (Free Edition's only option) and run all cells.
This writes the same dirty synthetic dataset the AWS version used —
`customers.csv`, `products.csv`, `transactions.csv` with injected duplicates,
missing fields, bad amounts/dates, and orphan references — straight into the
Volume's `raw/` folder. Same file, same `--n-transactions 5000` default,
same `random.seed(42)`.

Document the inferred-vs-corrected schema the same way the original project
did: open the three CSVs, note the inferred types Spark's `inferSchema` gives
you (via `df.printSchema()`), and compare against the same reasoning your
`docs/schema-*.md` files already wrote up — the corrections (amount as
`decimal(10,2)`, IDs kept as `string`, etc.) are handled inside
`transform.py`, unchanged.

## 4. Run 03_clean_and_curate_job once by hand

Set the `run_id` widget to something like `manual-test-1`, `catalog` and
`schema` to what you used in step 2, and run all cells. Watch the printed
`raw_count=... rejected_count=... curated_count=...` line at the bottom —
that's your proof-of-execution, same role the CloudWatch log line played.

This creates three Delta tables: `curated_transactions` (partitioned by
year/month/day), `rejected_transactions` (partitioned by run_id), and
`run_metrics`.

## 5. Run 04_catalog_and_publish_job once by hand

Same `catalog`/`schema` widgets. This republishes `curated_customers` and
`curated_products` in full and optimizes `curated_transactions` so it's fast
to query — the Databricks equivalent of the Athena `MSCK REPAIR TABLE` step.

## 6. Query the curated layer

Open `05_queries.sql`, find-and-replace `CATALOG.SCHEMA` with your real
values (e.g. `sales_pipeline.dev`), and run each of the six queries plus the
bonus `run_metrics` query — either in the **SQL Editor** (attach to your one
free SQL warehouse) or as `spark.sql(...)` cells in a notebook. Same six
analytical questions as the Athena version: monthly revenue trend, top 10
products, top 20 customers, average order value by category, month-over-month
growth, and the reject-rate breakdown.

## 7. Wire the two stages into a Workflow (requirement: ≥2 orchestrated stages)

**Workflows** (left sidebar) → **Jobs** → **Create Job**.

1. First task: name it `clean-and-curate`, type **Notebook**, path →
   `03_clean_and_curate_job`, compute → **Serverless**. Under **Parameters**
   set `run_id`, `catalog`, `schema` (use `{{job.start_time.iso_date}}` or
   similar for `run_id` if you want a fresh value every scheduled run, or a
   fixed string for manual testing).
2. Click **Add task** → name it `catalog-and-publish`, type **Notebook**,
   path → `04_catalog_and_publish_job`, compute → **Serverless**. Set
   **Depends on** → `clean-and-curate`. Set the same `catalog`/`schema`
   parameters.
3. **Create**. Click **Run now** and watch both tasks go green in sequence in
   the **Runs** tab — this is your orchestration proof, same role the Step
   Functions execution graph played.
4. Optional: add a schedule (**Schedule** tab) if the assignment wants a
   recurring run — daily, e.g.

Free Edition caps you at 5 concurrent job tasks account-wide, which a 2-task
pipeline never gets close to.

## 8. Rerun-safety proof (requirement 8)

Run `06_rerun_proof`. Part 1 reproduces the original local proof exactly
(two in-memory runs, matching checksums, no AWS/Databricks writes involved).
For Part 2: run the `clean-and-curate` Workflow task twice with the *same*
`run_id` and same input, then run the `06_rerun_proof` notebook's last cell
after each run — the row count and checksum on `curated_transactions` should
be identical both times, proving the dynamic-partition-overwrite write
replaced the same partitions instead of appending duplicates.

## Repo layout (this bundle)

```
00_setup.py                    creates the schema + Volume
01_generate_synthetic_data.py  writes the dirty synthetic CSVs into the Volume
transform.py                   all cleaning/validation/dedupe rules — unchanged from the AWS version
03_clean_and_curate_job.py     Stage 1 — writes curated_transactions, rejected_transactions, run_metrics
04_catalog_and_publish_job.py  Stage 2 — republishes dimension tables, optimizes curated_transactions
05_queries.sql                 the six analytical queries + bonus run_metrics query
06_rerun_proof.py              in-memory + table-level rerun-safety proof
```

## Free Edition constraints worth knowing before you start

- **Serverless-only compute** — you don't pick cluster size; usage is quota-limited per day/month.
- **One SQL warehouse**, capped at 2X-Small — fine for this dataset size, would not scale to a much bigger one.
- **5 concurrent job tasks** account-wide — irrelevant for a 2-task pipeline.
- **Outbound internet restricted to an allowlist** — this project needs none (no external package installs, no API calls), so it isn't affected.
- Exceeding a quota pauses compute for the rest of the day/month; it does not delete your tables or Volume data.

Sources: [Databricks Free Edition overview](https://docs.databricks.com/aws/en/getting-started/free-edition), [Databricks Free Edition limitations](https://docs.databricks.com/aws/en/getting-started/free-edition-limitations)
