# Databricks notebook source
# MAGIC %md
# MAGIC ## 00 — Setup: Unity Catalog schema + a Volume for the raw zone
# MAGIC
# MAGIC Run this notebook once. It creates:
# MAGIC - a schema to hold every table this project produces (curated, rejected, run_metrics)
# MAGIC - a Volume that plays the role your S3 `raw/` prefix played — plain files, readable
# MAGIC   with normal Python file I/O at `/Volumes/<catalog>/<schema>/raw_data/...`
# MAGIC
# MAGIC Free Edition workspaces come with a personal catalog already created for you
# MAGIC (usually named after your username, or `workspace`). Run `SHOW CATALOGS` first —
# MAGIC if `CREATE CATALOG` below fails with a permission error, just set CATALOG to
# MAGIC whatever catalog `SHOW CATALOGS` gives you and skip that one line.

# COMMAND ----------

CATALOG = "sales_pipeline"   # change to your existing catalog name if CREATE CATALOG is blocked
SCHEMA = "dev"

# COMMAND ----------

spark.sql("SHOW CATALOGS").show(truncate=False)

# COMMAND ----------

# Comment this line out if your account can't create catalogs on Free Edition —
# use an existing one from the list above instead.
spark.sql(f"CREATE CATALOG IF NOT EXISTS {CATALOG}")

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.{SCHEMA}")
spark.sql(f"CREATE VOLUME IF NOT EXISTS {CATALOG}.{SCHEMA}.raw_data")

print(f"Raw zone path -> /Volumes/{CATALOG}/{SCHEMA}/raw_data/raw/")
print("Ready. Run 01_generate_synthetic_data next.")
