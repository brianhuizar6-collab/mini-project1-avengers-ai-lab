# Databricks notebook source
# MAGIC %md
# MAGIC ## 03 — Stage 1: Clean & Curate
# MAGIC
# MAGIC Databricks equivalent of `glue_jobs/clean_and_curate_job.py`. Reads the raw CSVs
# MAGIC from the Volume, runs the same cleaning/validation/dedupe logic as the original
# MAGIC `etl/transform.py` (pasted directly into this notebook below — inlined rather
# MAGIC than imported from a separate workspace file, to sidestep a Free Edition
# MAGIC workspace-file I/O issue some accounts hit on cross-file imports), and writes:
# MAGIC - `curated_transactions` — a Delta table partitioned by year/month/day
# MAGIC - `rejected_transactions` — a Delta table partitioned by run_id
# MAGIC - `run_metrics` — one row per run, the raw/rejected/curated counts
# MAGIC
# MAGIC Rerun-safety (requirement 8) comes from `partitionOverwriteMode = dynamic`:
# MAGIC a write only replaces the partitions present in that run's output, so running
# MAGIC this notebook twice on identical input never duplicates rows.
# MAGIC
# MAGIC This notebook takes three widgets so it can be parameterized as a Databricks
# MAGIC Workflow task: `run_id`, `catalog`, `schema`.

# COMMAND ----------

dbutils.widgets.text("run_id", "manual-test-1")
dbutils.widgets.text("catalog", "sales_pipeline")
dbutils.widgets.text("schema", "dev")

RUN_ID = dbutils.widgets.get("run_id")
CATALOG = dbutils.widgets.get("catalog")
SCHEMA = dbutils.widgets.get("schema")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transform logic (inlined from transform.py)

# COMMAND ----------

from __future__ import annotations

from pyspark.sql import DataFrame, Window
from pyspark.sql import functions as F
from pyspark.sql import types as T

REQUIRED_TXN_COLUMNS = ["transaction_id", "customer_id", "product_id"]
MAX_AMOUNT_MULTIPLIER = 3.0

ISO_DATE_PATTERN = r"^\d{4}-\d{2}-\d{2}$"
US_DATE_PATTERN = r"^\d{1,2}/\d{1,2}/\d{4}$"


def standardize_column_names(df: DataFrame) -> DataFrame:
    for c in df.columns:
        clean = c.strip().lower().replace(" ", "_").replace("-", "_")
        if clean != c:
            df = df.withColumnRenamed(c, clean)
    return df


def _clean_amount_string(col):
    return F.regexp_replace(F.col(col), r"[$,\s]", "")


def standardize_transaction_types(df: DataFrame) -> DataFrame:
    df = df.withColumn("_amount_clean", _clean_amount_string("amount"))
    df = df.withColumn(
        "amount",
        F.when(F.col("_amount_clean").rlike(r"^-?\d+(\.\d+)?$"),
               F.col("_amount_clean").cast(T.DecimalType(10, 2)))
         .otherwise(F.lit(None).cast(T.DecimalType(10, 2)))
    ).drop("_amount_clean")

    # Databricks runs with ANSI mode on by default, where to_date() raises on a
    # shape-valid but semantically invalid date (e.g. "2019-13-40", month 13)
    # instead of returning NULL -- try_to_date() always returns NULL instead.
    iso = F.when(F.col("transaction_date").rlike(ISO_DATE_PATTERN),
                 F.try_to_date(F.col("transaction_date"), F.lit("yyyy-MM-dd")))
    us = F.when(F.col("transaction_date").rlike(US_DATE_PATTERN),
                F.try_to_date(F.col("transaction_date"), F.lit("MM/dd/yyyy")))
    df = df.withColumn("transaction_date", F.coalesce(iso, us))

    df = df.withColumn("ingestion_timestamp", F.to_timestamp("ingestion_timestamp"))
    df = df.withColumn("customer_id", F.trim(F.col("customer_id")))
    df = df.withColumn("product_id", F.trim(F.col("product_id")))
    df = df.withColumn("transaction_id", F.trim(F.col("transaction_id")))
    return df


def apply_missing_value_rules(df: DataFrame) -> DataFrame:
    missing_required = F.lit(False)
    for c in REQUIRED_TXN_COLUMNS:
        missing_required = missing_required | F.col(c).isNull() | (F.trim(F.col(c).cast("string")) == "")
    df = df.withColumn("_missing_required", missing_required)

    df = df.withColumn(
        "promo_code",
        F.when((F.col("promo_code").isNull()) | (F.trim(F.col("promo_code")) == ""), F.lit("NONE"))
         .otherwise(F.col("promo_code"))
    )
    df = df.withColumn("is_imputed", F.col("promo_code") == F.lit("NONE"))
    return df


def validate_amount(df: DataFrame, amount_ceiling) -> DataFrame:
    valid = F.col("amount").isNotNull() & (F.col("amount") > 0) & (F.col("amount") <= amount_ceiling)
    return df.withColumn("_valid_amount", valid)


def validate_date(df: DataFrame, min_date: str, max_date: str) -> DataFrame:
    valid = F.col("transaction_date").isNotNull() & \
        (F.col("transaction_date") >= F.lit(min_date)) & \
        (F.col("transaction_date") <= F.lit(max_date))
    return df.withColumn("_valid_date", valid)


def validate_references(df: DataFrame, customers_df: DataFrame, products_df: DataFrame) -> DataFrame:
    known_customers = F.broadcast(customers_df.select("customer_id").distinct()
                                   .withColumnRenamed("customer_id", "_known_customer_id"))
    known_products = F.broadcast(products_df.select("product_id").distinct()
                                  .withColumnRenamed("product_id", "_known_product_id"))

    df = df.join(known_customers, df.customer_id == known_customers._known_customer_id, "left")
    df = df.join(known_products, df.product_id == known_products._known_product_id, "left")
    df = df.withColumn("_valid_customer_ref", F.col("_known_customer_id").isNotNull())
    df = df.withColumn("_valid_product_ref", F.col("_known_product_id").isNotNull())
    return df.drop("_known_customer_id", "_known_product_id")


def assign_reject_reason(df: DataFrame) -> DataFrame:
    df = df.withColumn(
        "reject_reason",
        F.when(F.col("_missing_required"), F.lit("missing_required_field"))
         .when(~F.col("_valid_amount"), F.lit("invalid_amount"))
         .when(~F.col("_valid_date"), F.lit("invalid_date"))
         .when(~F.col("_valid_customer_ref") | ~F.col("_valid_product_ref"), F.lit("orphan_reference"))
         .otherwise(F.lit(None).cast("string"))
    )
    return df


def deterministic_dedupe(df: DataFrame) -> DataFrame:
    w = Window.partitionBy("transaction_id").orderBy(
        F.col("ingestion_timestamp").desc(), F.col("source_file").asc()
    )
    return (
        df.withColumn("_rn", F.row_number().over(w))
          .filter(F.col("_rn") == 1)
          .drop("_rn")
    )


def split_valid_invalid(df: DataFrame):
    valid = df.filter(F.col("reject_reason").isNull())
    invalid = df.filter(F.col("reject_reason").isNotNull())
    return valid, invalid


def add_partition_columns(df: DataFrame, date_col: str = "transaction_date") -> DataFrame:
    return (
        df.withColumn("year", F.date_format(F.col(date_col), "yyyy"))
          .withColumn("month", F.date_format(F.col(date_col), "MM"))
          .withColumn("day", F.date_format(F.col(date_col), "dd"))
    )


def drop_internal_columns(df: DataFrame) -> DataFrame:
    internal = ["_missing_required", "_valid_amount", "_valid_date",
                "_valid_customer_ref", "_valid_product_ref"]
    return df.drop(*[c for c in internal if c in df.columns])


def clean_and_curate(transactions_df: DataFrame, customers_df: DataFrame, products_df: DataFrame,
                      run_id: str, min_date: str = "2024-01-01", max_date: str = "2026-12-31"):
    df = standardize_column_names(transactions_df)
    df = standardize_transaction_types(df)
    df = apply_missing_value_rules(df)

    ninety_ninth = df.approxQuantile("amount", [0.99], 0.01)
    ceiling = float(ninety_ninth[0]) * MAX_AMOUNT_MULTIPLIER if ninety_ninth and ninety_ninth[0] else 1_000_000.0

    df = validate_amount(df, ceiling)
    df = validate_date(df, min_date, max_date)
    df = validate_references(df, standardize_column_names(customers_df), standardize_column_names(products_df))
    df = assign_reject_reason(df)

    raw_count = df.count()

    valid_df, invalid_df = split_valid_invalid(df)
    curated_df = deterministic_dedupe(valid_df)
    curated_df = add_partition_columns(curated_df)
    curated_df = drop_internal_columns(curated_df).withColumn("run_id", F.lit(run_id))

    rejected_df = drop_internal_columns(invalid_df).withColumn("run_id", F.lit(run_id))

    counts = {
        "run_id": run_id,
        "raw_count": raw_count,
        "rejected_count": rejected_df.count(),
        "curated_count": curated_df.count(),
    }
    return curated_df, rejected_df, counts

# COMMAND ----------

RAW_BASE = f"/Volumes/{CATALOG}/{SCHEMA}/raw_data/raw"

transactions = spark.read.option("header", True).option("inferSchema", True).csv(f"{RAW_BASE}/transactions")
customers = spark.read.option("header", True).option("inferSchema", True).csv(f"{RAW_BASE}/customers")
products = spark.read.option("header", True).option("inferSchema", True).csv(f"{RAW_BASE}/products")

# COMMAND ----------

curated_df, rejected_df, counts = clean_and_curate(transactions, customers, products, RUN_ID)

# COMMAND ----------

(
    curated_df.write.format("delta")
    .mode("overwrite")
    .partitionBy("year", "month", "day")
    .option("partitionOverwriteMode", "dynamic")
    .option("mergeSchema", "true")
    .saveAsTable(f"{CATALOG}.{SCHEMA}.curated_transactions")
)

(
    rejected_df.write.format("delta")
    .mode("overwrite")
    .partitionBy("run_id")
    .option("partitionOverwriteMode", "dynamic")
    .option("mergeSchema", "true")
    .saveAsTable(f"{CATALOG}.{SCHEMA}.rejected_transactions")
)

# COMMAND ----------

import datetime

metrics_row = spark.createDataFrame([{
    **counts,
    "stage": "clean_and_curate",
    "ts": datetime.datetime.utcnow().isoformat(),
}])
metrics_row.write.format("delta").mode("append").option("mergeSchema", "true") \
    .saveAsTable(f"{CATALOG}.{SCHEMA}.run_metrics")

# COMMAND ----------

# This printed line is requirement 10 (recording raw/rejected/curated counts) —
# visible directly in the notebook run's output, same role CloudWatch logs played.
print(f"run_id={counts['run_id']} raw_count={counts['raw_count']} "
      f"rejected_count={counts['rejected_count']} curated_count={counts['curated_count']}")
